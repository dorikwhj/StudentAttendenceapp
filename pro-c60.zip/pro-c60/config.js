import * as firebase from "firebase";

var firebaseConfig = {
    apiKey: "AIzaSyDMrePzfk1-_9fZ0fOqujhPZreY5gXqw_A",
    authDomain: "schoolattendanceapp-b831e.firebaseapp.com",
    databaseURL: "https://schoolattendanceapp-b831e-default-rtdb.firebaseio.com",
    projectId: "schoolattendanceapp-b831e",
    storageBucket: "schoolattendanceapp-b831e.appspot.com",
    messagingSenderId: "977504222712",
    appId: "1:977504222712:web:29dd1eb7072d19c4922a0d"
  };

export default !firebase.apps.length ? firebase.initializeApp(firebaseConfig) : firebase.app();
 

console.log(firebase.name);
console.log(firebase.database());
 
 

  